# METADATA
# scope: package
# title: Unneeded separate list operation after database retrieve
# description: A database retrieve whose result is only consumed by a single list operation could have that operation combined directly into the retrieve, avoiding an unnecessary extra pass over the list.
# authors:
# - Mark van der Smagt
# custom:
#  category: Performance
#  rulename: UnneededListOperations
#  severity: LOW
#  rulenumber: 008_0007
#  remediation: Combine the list operation's filter/sort/range directly into the database retrieve's Xpath constraint, sorting, or range, and remove the separate list operation.
#  input: .*\.Microflows\$Microflow\.yaml
package app.mendix.microflows.unneeded_list_operations

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

# ---------------------------------------------------------
# A list-typed variable is referenced either by its bare name in a
# reference field (ListName, ChangeVariableName, an XML export
# mapping's MappingVariableName, ...), or as the literal "$VarName"
# token when the list itself is passed/returned as a whole (an End
# Event's ReturnValue, a MicroflowCall or Java action parameter's
# Argument, ...) - never embedded inside a larger expression either
# way (XpathConstraint and split/filter Expression are scalar/boolean
# and can never hold a list reference, so those stay unchecked). Both
# forms must be counted as usages, or a list that's retrieved,
# filtered once, and then also passed on/returned elsewhere would be
# miscounted as "only used by one list operation".
# ---------------------------------------------------------
errors contains err if {
  ret := database_list_retrieves[_]
  idx := ret.idx
  var := ret.var

  count(end_event_return_usages(var)) == 0

  matches := other_usage_actions(idx, var)
  count(matches) == 1

  j := matches[_]
  usage := actions[j]

  contains(lower(type_of(usage)), "listoperationsaction")
  op := object.get(usage, "NewOperation", null)
  op != null
  op_type := lower(type_of(op))
  op_type in combinable_list_operation_types
  object.get(op, "ListName", "") == var

  not head_after_custom_range(actions[idx], op_type)
  not repeated_in_loop(actions[idx], usage, op_type)

  err := sprintf("[%v, %v, %v] Database retrieve '%v' is only consumed by one list operation (%v) - combine it into the retrieve instead",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      var,
      type_of(op),
    ]
  )
}

# ---------------------------------------------------------
# A custom range (skip/amount) always yields a list, so a Head after
# it cannot be folded into the retrieve, whatever the amount.
# ---------------------------------------------------------
head_after_custom_range(retrieve, op_type) if {
  op_type == "microflows$head"
  range := object.get(object.get(retrieve, "RetrieveSource", {}), "Range", null)
  range != null
  contains(lower(type_of(range)), "customrange")
}

# ---------------------------------------------------------
# A list operation inside a loop that does not also contain the
# retrieve runs once per iteration, so folding it into the retrieve
# is not possible without moving the retrieve into the loop. Sort
# stays reported: it yields the same result on every iteration.
# ---------------------------------------------------------
repeated_in_loop(retrieve, usage, op_type) if {
  op_type != "microflows$sort"
  loop_actions := loop_action_sets[_]
  usage in loop_actions
  not retrieve in loop_actions
}

# ---------------------------------------------------------
# One set per loop in the microflow: every action nested at any
# depth (up to the object tree's 4 levels) inside that loop's body.
# Built once and reused for every retrieve/usage pair.
# ---------------------------------------------------------
loop_action_sets := [s |
  loop := all_microflow_objects[_]
  contains(lower(type_of(loop)), "loopedactivity")
  s := {a |
    o := loop_body_objects(loop)[_]
    o["$Type"] == "Microflows$ActionActivity"
    a := object.get(o, "Action", null)
    a != null
  }
]

loop_body_objects(loop) := objs if {
  lvl0 := object.get(object.get(loop, "ObjectCollection", {}), "Objects", [])
  lvl1 := [o | p := lvl0[_]; o := object.get(object.get(p, "ObjectCollection", {}), "Objects", [])[_]]
  lvl2 := [o | p := lvl1[_]; o := object.get(object.get(p, "ObjectCollection", {}), "Objects", [])[_]]
  lvl3 := [o | p := lvl2[_]; o := object.get(object.get(p, "ObjectCollection", {}), "Objects", [])[_]]
  objs := array.concat(array.concat(lvl0, lvl1), array.concat(lvl2, lvl3))
}

# ---------------------------------------------------------
# DATABASE RETRIEVES
# ---------------------------------------------------------
database_list_retrieves := [{"idx": i, "var": v} |
  a := actions[i]
  contains(lower(type_of(a)), "retrieveaction")

  src := object.get(a, "RetrieveSource", null)
  src != null
  contains(lower(object.get(src, "$Type", "")), "databaseretrievesource")

  v := object.get(a, "ResultVariableName", "")
  v != ""
]

# ---------------------------------------------------------
# Index: exact string value -> indices of actions that contain that
# exact string anywhere among their own fields. Built once as a single
# pass over every action (its key, s, is unified directly against a
# value produced by the loop, which is the indexable form OPA's
# evaluator can turn into a lookup instead of a fresh scan), then
# reused by other_usage_actions for every retrieved list variable
# instead of re-walking every action's whole field tree once per
# variable.
# ---------------------------------------------------------
action_idxs_by_string[s] := idxs if {
  a0 := actions[_]
  s := strings_in_object(a0)[_]

  idxs := {j |
    a := actions[j]
    s2 := strings_in_object(a)[_]
    s2 == s
  }
}

action_idxs_for_string(s) := idxs if {
  idxs := action_idxs_by_string[s]
} else := set() if { true }

# ---------------------------------------------------------
# Every other action (excluding the retrieve itself) that
# references the retrieved variable anywhere among its own fields,
# either as its bare name (e.g. ListName, MappingVariableName) or as
# the "$var" token a list takes when passed/returned as a whole (e.g.
# a MicroflowCall or Java action parameter's Argument).
# ---------------------------------------------------------
other_usage_actions(idx, var) := idxs if {
  idxs := {j |
    j := (action_idxs_for_string(var) | action_idxs_for_string(sprintf("$%v", [var])))[_]
    j != idx
  }
}

# ---------------------------------------------------------
# Index: End Event ReturnValue -> the End Event objects with exactly
# that ReturnValue. Built once as a single pass over
# all_microflow_objects, then reused by end_event_return_usages for
# every retrieved list variable instead of re-scanning every microflow
# object once per variable.
# ---------------------------------------------------------
end_events_by_return_value[rv] := os if {
  o0 := all_microflow_objects[_]
  contains(lower(type_of(o0)), "endevent")
  rv := object.get(o0, "ReturnValue", "")

  os := {o |
    o := all_microflow_objects[_]
    contains(lower(type_of(o)), "endevent")
    object.get(o, "ReturnValue", "") == rv
  }
}

# ---------------------------------------------------------
# End Events that return the variable directly (ReturnValue holds
# exactly "$var", the only form a list can take there).
# ---------------------------------------------------------
end_event_return_usages(var) := os if {
  os := end_events_by_return_value[sprintf("$%v", [var])]
} else := set() if { true }

# ---------------------------------------------------------
# List operation types that map directly onto something settable
# on a DatabaseRetrieveSource (Xpath constraint, sorting, or range).
# ---------------------------------------------------------
combinable_list_operation_types := {
  "microflows$find",
  "microflows$filterbyexpression",
  "microflows$findbyexpression",
  "microflows$sort",
  "microflows$head",
  "microflows$tail",
  "microflows$listrange",
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Preferred display name for an activity in lint messages.
# Caption is the modeler-facing label, but it's frequently left blank -
# fall back to the variable the activity assigns its result to
# (ResultVariableName, or VariableName for the activity kinds that use
# that field instead), and only fall back further to the raw activity
# type if neither is set.
#
# Depends on: type_of.rego.part
# ---------------------------------------------------------
activity_caption(aa) := c if {
  c0 := object.get(aa, "Caption", "")
  c0 != ""
  c := c0
} else := c if {
  c0 := object.get(aa, "ResultVariableName", "")
  c0 != ""
  c := c0
} else := c if {
  c0 := object.get(aa, "VariableName", "")
  c0 != ""
  c := c0
} else := type_of(aa) if { true }

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# The set of ErrorHandlingType values (after normalize_eht) that
# count as "custom" error handling.
# Note: 008_0003 originally called this constant allowed_error_handling
# and 008_0004 called it allowed_custom_error_handling - same value,
# different name. Standardized on allowed_custom_error_handling.
# ---------------------------------------------------------
allowed_custom_error_handling := {
  "customwithrollback",
  "customwithoutrollback",
  "custom"
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Variables derived from $latestError via a Create or Change variable
# action whose InitialValue/Value contains "$latestError" (e.g.
# $ErrorMsg := $latestError/Message). Lets a rule recognize error-handling
# code that references the error indirectly through such a variable, not
# just $latestError itself.
#
# Was previously hand-duplicated (byte-for-byte) inside both
# 008_0004_custom_error_handling_latest_error_usage.rule.part and
# 008_0015_no_raw_error_messages_to_user.rule.part - consolidated here.
#
# Depends on: microflow_object_tree.rego.part (actions),
#             is_create_variable_action.rego.part,
#             is_change_variable_action.rego.part
# ---------------------------------------------------------
derived_error_vars := derived_create_vars | derived_change_vars

derived_create_vars := {v |
  act := actions[_]
  is_create_variable_action(act)

  expr := object.get(act, "InitialValue", "")
  contains(expr, "$latestError")

  v := object.get(act, "VariableName", "")
  v != ""
}

derived_change_vars := {v |
  act := actions[_]
  is_change_variable_action(act)

  expr := object.get(act, "Value", "")
  contains(expr, "$latestError")

  v := object.get(act, "ChangeVariableName", "")
  v != ""
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Normalizes an ErrorHandlingType value (e.g. "Custom With Rollback",
# "custom_with_rollback") down to a comparable lowercase-letters-only
# form, e.g. "customwithrollback".
# ---------------------------------------------------------
normalize_eht(s) := out if {
  lower_s := lower(s)
  no_sep := replace(replace(replace(lower_s, " ", ""), "_", ""), "-", "")
  chars := [c | c := split(no_sep, "")[_]; is_letter(c)]
  out := concat("", chars)
}

is_letter(c) if {
  c >= "a"
  c <= "z"
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Pulls every $Variable reference out of an XPath constraint or any other
# microflow expression string (list-operation filters, decision-split
# conditions, ...).
# ---------------------------------------------------------
extract_variables(expr) := vars if {
  # Mendix can export (or a modeler can author) an expression with a
  # literal line break landing inside a compound $Var/Association path,
  # e.g. "$HouseHold/\nAddress" instead of "$HouseHold/Address". Rejoin
  # a newline that touches a "/" before treating whitespace as a token
  # separator below, or the segment after the break (here "Address")
  # gets silently dropped since it no longer starts with "$". Only a
  # newline-containing whitespace run adjacent to "/" is collapsed here
  # - plain spaces around "/" (e.g. "$Amount / 2") are left untouched,
  # so this can't merge two space-separated $Var tokens either side of
  # a division operator.
  step1 := regex.replace(expr, `/[ \t]*\r?\n[ \t\r\n]*`, "/")
  rejoined := regex.replace(step1, `[ \t\r\n]*\r?\n[ \t]*/`, "/")

  normalized := replace(replace(replace(replace(replace(replace(replace(replace(replace(rejoined, "[", " "), "]", " "), "AND", " "), "OR", " "), ")", " "), "(", " ") ,"\t"," "),"\r"," "),"\n"," ")
  parts := split(normalized, " ")

  vars := {trim_prefix(trim(p, " "), "$") |
    p := parts[_]
    startswith(p, "$")
  }
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Depends on: type_of.rego.part
# ---------------------------------------------------------
is_change_variable_action(a) if {
  contains(lower(type_of(a)), "changevariableaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Depends on: type_of.rego.part
# ---------------------------------------------------------
is_create_variable_action(a) if {
  contains(lower(type_of(a)), "createvariableaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Flattens a microflow's nested ObjectCollection.Objects tree
# (up to 4 levels of nesting, e.g. inside loops/exclusive splits)
# into one array, and extracts the Action of every ActionActivity.
# ---------------------------------------------------------
actions := [a |
  aa := all_microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"

  a := object.get(aa, "Action", null)
  a != null
]

# An array, not a set, so that byte-for-byte identical objects (e.g. two
# identical LogMessage activities) each keep their own entry for rules
# that count occurrences.
all_microflow_objects := array.concat(
  array.concat(
    array.concat(microflow_objects_lvl0, microflow_objects_lvl1),
    array.concat(microflow_objects_lvl2, microflow_objects_lvl3)
  ),
  microflow_objects_lvl4
)

microflow_objects_lvl0 := input.ObjectCollection.Objects

microflow_objects_lvl1 := [o |
  parent := microflow_objects_lvl0[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl2 := [o |
  parent := microflow_objects_lvl1[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl3 := [o |
  parent := microflow_objects_lvl2[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl4 := [o |
  parent := microflow_objects_lvl3[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Identifies "retrieve or create" pattern microflows by name,
# and whether they delegate to another microflow (in which case
# the retrieve/create checks that live in the caller don't apply).
# Depends on: microflow_object_tree.rego.part (actions)
# ---------------------------------------------------------
is_retrieve_or_create_microflow if {
  name := lower(input.Name)
  contains(name, "retrieve")
  contains(name, "create")
}

contains_microflowcall if{
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "microflowcallaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Variables read via a database Retrieve action, either through
# an association path or an XPath constraint.
# Depends on: microflow_object_tree.rego.part (actions),
#             extract_variables.rego.part
# ---------------------------------------------------------

# Assoc retrieve
retrieve_assoc_vars := {v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource","")
  contains(lower(object.get(src, "$Type", "")), "associationretrievesource")

  v := object.get(src, "StartVariableName", "")
  v != ""
}

# XPATH VARIABLE Retrieve
retrieve_xpath_vars := {v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource", null)
  src != null
  contains(lower(object.get(src, "$Type", "")), "databaseretrievesource")

  xpath := object.get(src, "XpathConstraint", "")
  xpath != ""

  v := extract_variables(xpath)[_]
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Deep traversal: collect every string value nested anywhere
# inside an object (used to scan expressions/log messages for
# a substring regardless of which field it's stored in).
#
# Note: standardized to a set here. The original 008_0004 had this
# as an array comprehension, but every call site only ever iterates
# it with `strings_in_object(x)[_]`, which is order-independent, so
# using a set here is behavior-preserving for both callers.
# ---------------------------------------------------------
strings_in_object(x) := {s |
  some path, v
  walk(x, [path, v])
  is_string(v)
  s := v
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Type accessor: Mendix modelsource YAML uses either $Type or
# $type depending on export version.
# ---------------------------------------------------------
type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if { true }
