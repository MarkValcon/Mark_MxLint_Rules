# METADATA
# scope: package
# title: Uncommitted status change may be returned to client
# description: A Change Object or Create Object activity in a microflow that a UserRole can call directly (AllowedModuleRoles is non-empty) that sets a status attribute but is never committed can still return its in-memory value to the client - letting a user see (and act on) a status change that was never actually persisted or authorized.
# authors:
# - Mark van der Smagt
# custom:
#  category: Security
#  rulename: UncommittedStatusChangeReturned
#  severity: HIGH
#  rulenumber: 008_0016
#  remediation: Commit the changed/created object for the same variable (set the action's own Commit property to Yes, or add a separate Commit activity) within this microflow before the value can be returned to the client.
#  input: .*\.Microflows\$Microflow\.yaml
package app.mendix.microflows.uncommitted_status_change_returned

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

errors contains err if {
  is_client_facing_microflow

  a := actions[_]
  is_object_change_action(a)

  item := object.get(a, "Items", [])[_]
  attr := object.get(item, "Attribute", "")
  attr != ""
  sensitive_attribute(attr)

  variable := object_variable_of(a)
  variable != ""

  not is_committed(a, variable)

  err := sprintf("[%v, %v, %v] Activity changing/creating %v sets %v but is never committed in this microflow - the uncommitted in-memory value can still be returned to the client",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      variable,
      attr,
    ]
  )
}

# ---------------------------------------------------------
# SCOPE: a microflow with at least one AllowedModuleRoles entry can be
# called directly by an end user (e.g. from a page action, data source,
# or REST call) - same mechanism 008_0009 uses for the same concept.
# A naming convention (e.g. ACT_/DS_/NAV_ prefixes) isn't reliable: it
# only reflects a team's convention, not whether a UserRole can actually
# reach the microflow.
# ---------------------------------------------------------
is_client_facing_microflow if {
  count(object.get(input, "AllowedModuleRoles", [])) > 0
}

# ---------------------------------------------------------
# Matches Microflows$ChangeAction and Microflows$CreateChangeAction
# (both carry Items[].Attribute/Value) - not ChangeVariableAction.
# ---------------------------------------------------------
is_object_change_action(a) if {
  contains(lower(type_of(a)), "changeaction")
}

# "amount" was dropped from this check (too many false positives in
# practice) - status only, for now.
sensitive_attribute(attr) if {
  contains(lower(attr), "status")
}

# ---------------------------------------------------------
# The variable this action created or changed - ChangeVariableName
# for Microflows$ChangeAction, VariableName for Microflows$CreateChangeAction.
# Exactly one of these is ever populated for a given action, so this
# can't produce conflicting outputs for the same input.
# ---------------------------------------------------------
object_variable_of(a) := v if {
  v := object.get(a, "ChangeVariableName", "")
  v != ""
}

object_variable_of(a) := v if {
  v := object.get(a, "VariableName", "")
  v != ""
}

# ---------------------------------------------------------
# Satisfied by an inline Commit on the action itself, or a separate
# CommitAction anywhere in this microflow naming the same variable.
# No ordering ("later") is checked: Mendix modelsource exports carry
# no SequenceFlow data, so before/after can't be determined from this
# input at all - every other rule in this ruleset already treats a
# microflow's actions as an unordered set for the same reason. Calls
# into other microflows are out of scope by construction, since
# `actions` only ever contains this microflow's own activities.
# ---------------------------------------------------------
is_committed(a, variable) if {
  startswith(lower(object.get(a, "Commit", "no")), "yes")
}

is_committed(a, variable) if {
  c := actions[_]
  contains(lower(type_of(c)), "commitaction")
  object.get(c, "CommitVariableName", "") == variable
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Preferred display name for an activity in lint messages.
# Caption is the modeler-facing label, but it's frequently left blank -
# fall back to the variable the activity assigns its result to
# (ResultVariableName, or VariableName for the activity kinds that use
# that field instead), and only fall back further to the raw activity
# type if neither is set.
#
# Depends on: type_of.rego.part
# ---------------------------------------------------------
activity_caption(aa) := c if {
  c0 := object.get(aa, "Caption", "")
  c0 != ""
  c := c0
} else := c if {
  c0 := object.get(aa, "ResultVariableName", "")
  c0 != ""
  c := c0
} else := c if {
  c0 := object.get(aa, "VariableName", "")
  c0 != ""
  c := c0
} else := type_of(aa) if { true }

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# The set of ErrorHandlingType values (after normalize_eht) that
# count as "custom" error handling.
# Note: 008_0003 originally called this constant allowed_error_handling
# and 008_0004 called it allowed_custom_error_handling - same value,
# different name. Standardized on allowed_custom_error_handling.
# ---------------------------------------------------------
allowed_custom_error_handling := {
  "customwithrollback",
  "customwithoutrollback",
  "custom"
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Normalizes an ErrorHandlingType value (e.g. "Custom With Rollback",
# "custom_with_rollback") down to a comparable lowercase-letters-only
# form, e.g. "customwithrollback".
# ---------------------------------------------------------
normalize_eht(s) := out if {
  lower_s := lower(s)
  no_sep := replace(replace(replace(lower_s, " ", ""), "_", ""), "-", "")
  chars := [c | c := split(no_sep, "")[_]; is_letter(c)]
  out := concat("", chars)
}

is_letter(c) if {
  c >= "a"
  c <= "z"
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Pulls every $Variable reference out of an XPath constraint or any other
# microflow expression string (list-operation filters, decision-split
# conditions, ...).
# ---------------------------------------------------------
extract_variables(expr) := vars if {
  # Mendix can export (or a modeler can author) an expression with a
  # literal line break landing inside a compound $Var/Association path,
  # e.g. "$HouseHold/\nAddress" instead of "$HouseHold/Address". Rejoin
  # a newline that touches a "/" before treating whitespace as a token
  # separator below, or the segment after the break (here "Address")
  # gets silently dropped since it no longer starts with "$". Only a
  # newline-containing whitespace run adjacent to "/" is collapsed here
  # - plain spaces around "/" (e.g. "$Amount / 2") are left untouched,
  # so this can't merge two space-separated $Var tokens either side of
  # a division operator.
  step1 := regex.replace(expr, `/[ \t]*\r?\n[ \t\r\n]*`, "/")
  rejoined := regex.replace(step1, `[ \t\r\n]*\r?\n[ \t]*/`, "/")

  normalized := replace(replace(replace(replace(replace(replace(replace(replace(replace(rejoined, "[", " "), "]", " "), "AND", " "), "OR", " "), ")", " "), "(", " ") ,"\t"," "),"\r"," "),"\n"," ")
  parts := split(normalized, " ")

  vars := {trim_prefix(trim(p, " "), "$") |
    p := parts[_]
    startswith(p, "$")
  }
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Depends on: type_of.rego.part
# ---------------------------------------------------------
is_create_variable_action(a) if {
  contains(lower(type_of(a)), "createvariableaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Flattens a microflow's nested ObjectCollection.Objects tree
# (up to 4 levels of nesting, e.g. inside loops/exclusive splits)
# into one set, and extracts the Action of every ActionActivity.
# ---------------------------------------------------------
actions := [a |
  aa := all_microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"

  a := object.get(aa, "Action", null)
  a != null
]

all_microflow_objects := objs if {
  objs := {o |
    o := microflow_objects_lvl0[_]
  } |
  {o |
    o := microflow_objects_lvl1[_]
  } |
  {o |
    o := microflow_objects_lvl2[_]
  } |
  {o |
    o := microflow_objects_lvl3[_]
  } |
  {o |
    o := microflow_objects_lvl4[_]
  }
}

microflow_objects_lvl0 := input.ObjectCollection.Objects

microflow_objects_lvl1 := [o |
  parent := microflow_objects_lvl0[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl2 := [o |
  parent := microflow_objects_lvl1[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl3 := [o |
  parent := microflow_objects_lvl2[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl4 := [o |
  parent := microflow_objects_lvl3[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Identifies "retrieve or create" pattern microflows by name,
# and whether they delegate to another microflow (in which case
# the retrieve/create checks that live in the caller don't apply).
# Depends on: microflow_object_tree.rego.part (actions)
# ---------------------------------------------------------
is_retrieve_or_create_microflow if {
  name := lower(input.Name)
  contains(name, "retrieve")
  contains(name, "create")
}

contains_microflowcall if{
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "microflowcallaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Variables read via a database Retrieve action, either through
# an association path or an XPath constraint.
# Depends on: microflow_object_tree.rego.part (actions),
#             extract_variables.rego.part
# ---------------------------------------------------------

# Assoc retrieve
retrieve_assoc_vars := {v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource","")
  contains(lower(object.get(src, "$Type", "")), "associationretrievesource")

  v := object.get(src, "StartVariableName", "")
  v != ""
}

# XPATH VARIABLE Retrieve
retrieve_xpath_vars := {v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource", null)
  src != null
  contains(lower(object.get(src, "$Type", "")), "databaseretrievesource")

  xpath := object.get(src, "XpathConstraint", "")
  xpath != ""

  v := extract_variables(xpath)[_]
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Deep traversal: collect every string value nested anywhere
# inside an object (used to scan expressions/log messages for
# a substring regardless of which field it's stored in).
#
# Note: standardized to a set here. The original 008_0004 had this
# as an array comprehension, but every call site only ever iterates
# it with `strings_in_object(x)[_]`, which is order-independent, so
# using a set here is behavior-preserving for both callers.
# ---------------------------------------------------------
strings_in_object(x) := {s |
  some path, v
  walk(x, [path, v])
  is_string(v)
  s := v
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Type accessor: Mendix modelsource YAML uses either $Type or
# $type depending on export version.
# ---------------------------------------------------------
type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if { true }
