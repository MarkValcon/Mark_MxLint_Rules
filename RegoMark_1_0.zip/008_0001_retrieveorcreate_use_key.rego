# METADATA
# scope: package
# title: Incorrect RetrieveOrCreate pattern
# description: Setting only the key values in retrieve or create microflows is essential for maintaining your application
# authors:
# - Mark van der Smagt
# custom:
#  category: Maintainability
#  rulename: RetrieveOrCreateUseKey
#  severity: MEDIUM
#  rulenumber: 008_0001
#  remediation: Use only the key values as input parameters and use only these to retrieve the object.
#  input: .*\.Microflows\$Microflow\.yaml
package app.mendix.domain_model.retrieveorcreate_use_key

import rego.v1

# GENERATED FILE - do not edit the .rego output directly.
# Source: src/rules/008_0001_retrieveorcreate_use_key.rule.part
# plus shared parts listed in generate.sh, assembled by generate.sh.

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

# ---------------------------------------------------------
# RULE 1: EACH PARAM (OR DERIVED) MUST BE USED IN RETRIEVE
# ---------------------------------------------------------
errors contains err if {
  is_retrieve_or_create_microflow
  not contains_microflowcall

  p := input_parameters[_]
  group := valid_representations[p]


  not exists_in_retrieve_base(group)

  err := sprintf("[%v, %v, %v] Parameter '%v' (or derived: %v) not used in retrieve (retrieve: %v)",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      p,
      group,
      retrieve_all
    ]
  )
}

# ---------------------------------------------------------
# INPUT PARAMETERS
# ---------------------------------------------------------
input_parameters := {p |
  o := all_microflow_objects[_]
  contains(lower(type_of(o)), "microflowparameter")
  variabletype := object.get(o, "VariableType", null)
  variabletype != null
  not contains(lower(type_of(variabletype)), "listtype")
  p := o.Name
}

# ---------------------------------------------------------
# GROUP INPUT PARAMETER WITH DERIVATIONS INTO REPRESENTATION (2 LEVELS)
# ---------------------------------------------------------

valid_representations[p] := reps if {
  p := input_parameters[_]

  lvl1 := {v |
    pair := param_derivation_lvl1[_]
    pair[0] == p
    v := pair[1]
  }

  lvl2 := {v |
    pair := param_derivation_lvl2[_]
    pair[0] == p
    v := pair[1]
  }

  reps := {p} | lvl1 | lvl2
}

param_derivation_lvl1 := { [p, v] |
  act := actions[_]

  is_create_variable_action(act)

  expr := object.get(act, "InitialValue", "")

  vars := extract_variables(expr)

  vx := vars[_]
  base := base_var(vx)

  input_parameters[base]

  p := base

  v := object.get(act, "VariableName", "")
  v != ""
}

param_derivation_lvl2 := { [p, v2] |
  pair := param_derivation_lvl1[_]
  p := pair[0]
  v1 := pair[1]

  act := actions[_]

  is_create_variable_action(act)

  expr := object.get(act, "InitialValue", "")

  vars := extract_variables(expr)

  vx := vars[_]
  base_var(vx) == v1

  v2 := object.get(act, "VariableName", "")
  v2 != ""
}

is_find_filter_operation(operation) if {
  contains(lower(type_of(operation)), "find")
} else if {
  contains(lower(type_of(operation)), "filter")
}

# ---------------------------------------------------------
# RETRIEVE VARIABLES
# ---------------------------------------------------------

exists_in_retrieve_base(group) if {
  some v
  group[v]
  retrieve_base[v]
}

# Normalized retrieve (for param coverage only)
retrieve_base := {b |
  v := retrieve_all[_]
  b := base_var(v)
}

retrieve_all := {v |
  retrieve_assoc_vars[v]
} | {v |
  retrieve_xpath_vars[v]
} | {v |
  retrieve_find_vars[v]
}

retrieve_find_vars := { v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "listoperationsaction")
  listoperation := object.get(a, "NewOperation", null)
  listoperation != null
  is_find_filter_operation(listoperation)
  expression := object.get(listoperation, "Expression", null)
  expression != null
  v:= extract_variables(expression)[_]
}

# ---------------------------------------------------------
# HELPERS
# ---------------------------------------------------------
# Normalize variable to its base (before '/')
base_var(v) := b if {
  parts := split(v, "/")
  b := parts[0]
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Preferred display name for an activity in lint messages.
# Caption is the modeler-facing label, but it's frequently left blank -
# fall back to the variable the activity assigns its result to
# (ResultVariableName, or VariableName for the activity kinds that use
# that field instead), and only fall back further to the raw activity
# type if neither is set.
#
# Depends on: type_of.rego.part
# ---------------------------------------------------------
activity_caption(aa) := c if {
  c0 := object.get(aa, "Caption", "")
  c0 != ""
  c := c0
} else := c if {
  c0 := object.get(aa, "ResultVariableName", "")
  c0 != ""
  c := c0
} else := c if {
  c0 := object.get(aa, "VariableName", "")
  c0 != ""
  c := c0
} else := type_of(aa) if { true }

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# The set of ErrorHandlingType values (after normalize_eht) that
# count as "custom" error handling.
# Note: 008_0003 originally called this constant allowed_error_handling
# and 008_0004 called it allowed_custom_error_handling - same value,
# different name. Standardized on allowed_custom_error_handling.
# ---------------------------------------------------------
allowed_custom_error_handling := {
  "customwithrollback",
  "customwithoutrollback",
  "custom"
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Normalizes an ErrorHandlingType value (e.g. "Custom With Rollback",
# "custom_with_rollback") down to a comparable lowercase-letters-only
# form, e.g. "customwithrollback".
# ---------------------------------------------------------
normalize_eht(s) := out if {
  lower_s := lower(s)
  no_sep := replace(replace(replace(lower_s, " ", ""), "_", ""), "-", "")
  chars := [c | c := split(no_sep, "")[_]; is_letter(c)]
  out := concat("", chars)
}

is_letter(c) if {
  c >= "a"
  c <= "z"
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Pulls every $Variable reference out of an XPath constraint or any other
# microflow expression string (list-operation filters, decision-split
# conditions, ...).
# ---------------------------------------------------------
extract_variables(expr) := vars if {
  # Mendix can export (or a modeler can author) an expression with a
  # literal line break landing inside a compound $Var/Association path,
  # e.g. "$HouseHold/\nAddress" instead of "$HouseHold/Address". Rejoin
  # a newline that touches a "/" before treating whitespace as a token
  # separator below, or the segment after the break (here "Address")
  # gets silently dropped since it no longer starts with "$". Only a
  # newline-containing whitespace run adjacent to "/" is collapsed here
  # - plain spaces around "/" (e.g. "$Amount / 2") are left untouched,
  # so this can't merge two space-separated $Var tokens either side of
  # a division operator.
  step1 := regex.replace(expr, `/[ \t]*\r?\n[ \t\r\n]*`, "/")
  rejoined := regex.replace(step1, `[ \t\r\n]*\r?\n[ \t]*/`, "/")

  normalized := replace(replace(replace(replace(replace(replace(replace(replace(replace(rejoined, "[", " "), "]", " "), "AND", " "), "OR", " "), ")", " "), "(", " ") ,"\t"," "),"\r"," "),"\n"," ")
  parts := split(normalized, " ")

  vars := {trim_prefix(trim(p, " "), "$") |
    p := parts[_]
    startswith(p, "$")
  }
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Depends on: type_of.rego.part
# ---------------------------------------------------------
is_create_variable_action(a) if {
  contains(lower(type_of(a)), "createvariableaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Flattens a microflow's nested ObjectCollection.Objects tree
# (up to 4 levels of nesting, e.g. inside loops/exclusive splits)
# into one set, and extracts the Action of every ActionActivity.
# ---------------------------------------------------------
actions := [a |
  aa := all_microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"

  a := object.get(aa, "Action", null)
  a != null
]

all_microflow_objects := objs if {
  objs := {o |
    o := microflow_objects_lvl0[_]
  } |
  {o |
    o := microflow_objects_lvl1[_]
  } |
  {o |
    o := microflow_objects_lvl2[_]
  } |
  {o |
    o := microflow_objects_lvl3[_]
  } |
  {o |
    o := microflow_objects_lvl4[_]
  }
}

microflow_objects_lvl0 := input.ObjectCollection.Objects

microflow_objects_lvl1 := [o |
  parent := microflow_objects_lvl0[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl2 := [o |
  parent := microflow_objects_lvl1[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl3 := [o |
  parent := microflow_objects_lvl2[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl4 := [o |
  parent := microflow_objects_lvl3[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Identifies "retrieve or create" pattern microflows by name,
# and whether they delegate to another microflow (in which case
# the retrieve/create checks that live in the caller don't apply).
# Depends on: microflow_object_tree.rego.part (actions)
# ---------------------------------------------------------
is_retrieve_or_create_microflow if {
  name := lower(input.Name)
  contains(name, "retrieve")
  contains(name, "create")
}

contains_microflowcall if{
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "microflowcallaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Variables read via a database Retrieve action, either through
# an association path or an XPath constraint.
# Depends on: microflow_object_tree.rego.part (actions),
#             extract_variables.rego.part
# ---------------------------------------------------------

# Assoc retrieve
retrieve_assoc_vars := {v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource","")
  contains(lower(object.get(src, "$Type", "")), "associationretrievesource")

  v := object.get(src, "StartVariableName", "")
  v != ""
}

# XPATH VARIABLE Retrieve
retrieve_xpath_vars := {v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource", null)
  src != null
  contains(lower(object.get(src, "$Type", "")), "databaseretrievesource")

  xpath := object.get(src, "XpathConstraint", "")
  xpath != ""

  v := extract_variables(xpath)[_]
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Deep traversal: collect every string value nested anywhere
# inside an object (used to scan expressions/log messages for
# a substring regardless of which field it's stored in).
#
# Note: standardized to a set here. The original 008_0004 had this
# as an array comprehension, but every call site only ever iterates
# it with `strings_in_object(x)[_]`, which is order-independent, so
# using a set here is behavior-preserving for both callers.
# ---------------------------------------------------------
strings_in_object(x) := {s |
  some path, v
  walk(x, [path, v])
  is_string(v)
  s := v
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Type accessor: Mendix modelsource YAML uses either $Type or
# $type depending on export version.
# ---------------------------------------------------------
type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if { true }
