# METADATA
# scope: package
# title: Primitive parameter on a microflow with UserRole access
# description: A microflow with at least one AllowedModuleRoles entry can be called directly by an end user (e.g. from a page action or REST call). A primitive parameter (String, Integer, Decimal, DateTime, Enumeration) carries no object-level access check the way an association/object parameter does, so a caller can supply any value and potentially reach objects they don't have rights to. Boolean is excluded (too low-cardinality to matter). A parameter that's checked in a decision split (whether an inline expression or a call to a validation rule microflow), or handed off to a VAL_-prefixed validation microflow, is excluded too.
# authors:
# - Mark van der Smagt
# custom:
#  category: Security
#  rulename: NoPrimitiveParamsOnUserRoleMicroflows
#  severity: HIGH
#  rulenumber: 008_0009
#  remediation: Replace the primitive parameter with an association/object parameter so Mendix's built-in entity access applies, or add a decision split (or a VAL_-prefixed validation microflow) that checks the supplied value before it's used.
#  input: .*\.Microflows\$Microflow\.yaml
package app.mendix.microflows.no_primitive_params_on_userrole_microflows

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

errors contains err if {
  count(object.get(input, "AllowedModuleRoles", [])) > 0

  param := parameters[_]
  is_primitive_parameter(param)

  not excluded_by_decision_split(param)
  not excluded_by_val_microflow_call(param)

  err := sprintf("[%v, %v, %v] Parameter %v is a primitive type (%v) on a microflow with UserRole access - a caller can supply it directly",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      param.Name,
      type_of(object.get(param, "VariableType", {})),
    ]
  )
}

# ---------------------------------------------------------
# PARAMETERS
# ---------------------------------------------------------
parameters := [p |
  p := all_microflow_objects[_]
  contains(lower(type_of(p)), "microflowparameter")
]

primitive_type_names := {
  "datatypes$stringtype",
  "datatypes$integertype",
  "datatypes$decimaltype",
  "datatypes$datetimetype",
  "datatypes$enumerationtype",
}

is_primitive_parameter(p) if {
  t := lower(type_of(object.get(p, "VariableType", {})))
  t in primitive_type_names
}

# ---------------------------------------------------------
# EXCLUSION: parameter is checked in a decision split - either inline
# in an ExpressionSplitCondition's Expression string, or passed as an
# argument to a validation rule microflow via a RuleSplitCondition.
# ---------------------------------------------------------
excluded_by_decision_split(p) if {
  split := splits[_]
  expr := object.get(object.get(split, "SplitCondition", {}), "Expression", "")
  p.Name in extract_variables(expr)
}

excluded_by_decision_split(p) if {
  split := splits[_]
  rule_call := object.get(object.get(split, "SplitCondition", {}), "RuleCall", {})
  mapping := object.get(rule_call, "ParameterMappings", [])[_]
  object.get(mapping, "Argument", "") == sprintf("$%v", [p.Name])
}

splits := [o |
  o := all_microflow_objects[_]
  contains(lower(type_of(o)), "exclusivesplit")
]

# ---------------------------------------------------------
# EXCLUSION: parameter is passed as-is to a VAL_-prefixed microflow.
# This only checks that the call is made - it can't verify the callee
# actually validates the value, since that's a different modelsource
# file this rule never sees.
# ---------------------------------------------------------
excluded_by_val_microflow_call(p) if {
  a := actions[_]
  contains(lower(type_of(a)), "microflowcallaction")

  call := object.get(a, "MicroflowCall", {})
  callee := object.get(call, "Microflow", "")
  callee != ""

  segments := split(callee, ".")
  last_segment := segments[count(segments) - 1]
  startswith(last_segment, "VAL_")

  mapping := object.get(call, "ParameterMappings", [])[_]
  object.get(mapping, "Argument", "") == sprintf("$%v", [p.Name])
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Preferred display name for an activity in lint messages.
# Caption is the modeler-facing label, but it's frequently left blank -
# fall back to the variable the activity assigns its result to
# (ResultVariableName, or VariableName for the activity kinds that use
# that field instead), and only fall back further to the raw activity
# type if neither is set.
#
# Depends on: type_of.rego.part
# ---------------------------------------------------------
activity_caption(aa) := c if {
  c0 := object.get(aa, "Caption", "")
  c0 != ""
  c := c0
} else := c if {
  c0 := object.get(aa, "ResultVariableName", "")
  c0 != ""
  c := c0
} else := c if {
  c0 := object.get(aa, "VariableName", "")
  c0 != ""
  c := c0
} else := type_of(aa) if { true }

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# The set of ErrorHandlingType values (after normalize_eht) that
# count as "custom" error handling.
# Note: 008_0003 originally called this constant allowed_error_handling
# and 008_0004 called it allowed_custom_error_handling - same value,
# different name. Standardized on allowed_custom_error_handling.
# ---------------------------------------------------------
allowed_custom_error_handling := {
  "customwithrollback",
  "customwithoutrollback",
  "custom"
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Variables derived from $latestError via a Create or Change variable
# action whose InitialValue/Value contains "$latestError" (e.g.
# $ErrorMsg := $latestError/Message). Lets a rule recognize error-handling
# code that references the error indirectly through such a variable, not
# just $latestError itself.
#
# Was previously hand-duplicated (byte-for-byte) inside both
# 008_0004_custom_error_handling_latest_error_usage.rule.part and
# 008_0015_no_raw_error_messages_to_user.rule.part - consolidated here.
#
# Depends on: microflow_object_tree.rego.part (actions),
#             is_create_variable_action.rego.part,
#             is_change_variable_action.rego.part
# ---------------------------------------------------------
derived_error_vars := derived_create_vars | derived_change_vars

derived_create_vars := {v |
  act := actions[_]
  is_create_variable_action(act)

  expr := object.get(act, "InitialValue", "")
  contains(expr, "$latestError")

  v := object.get(act, "VariableName", "")
  v != ""
}

derived_change_vars := {v |
  act := actions[_]
  is_change_variable_action(act)

  expr := object.get(act, "Value", "")
  contains(expr, "$latestError")

  v := object.get(act, "ChangeVariableName", "")
  v != ""
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Normalizes an ErrorHandlingType value (e.g. "Custom With Rollback",
# "custom_with_rollback") down to a comparable lowercase-letters-only
# form, e.g. "customwithrollback".
# ---------------------------------------------------------
normalize_eht(s) := out if {
  lower_s := lower(s)
  no_sep := replace(replace(replace(lower_s, " ", ""), "_", ""), "-", "")
  chars := [c | c := split(no_sep, "")[_]; is_letter(c)]
  out := concat("", chars)
}

is_letter(c) if {
  c >= "a"
  c <= "z"
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Pulls every $Variable reference out of an XPath constraint or any other
# microflow expression string (list-operation filters, decision-split
# conditions, ...).
# ---------------------------------------------------------
extract_variables(expr) := vars if {
  # Mendix can export (or a modeler can author) an expression with a
  # literal line break landing inside a compound $Var/Association path,
  # e.g. "$HouseHold/\nAddress" instead of "$HouseHold/Address". Rejoin
  # a newline that touches a "/" before treating whitespace as a token
  # separator below, or the segment after the break (here "Address")
  # gets silently dropped since it no longer starts with "$". Only a
  # newline-containing whitespace run adjacent to "/" is collapsed here
  # - plain spaces around "/" (e.g. "$Amount / 2") are left untouched,
  # so this can't merge two space-separated $Var tokens either side of
  # a division operator.
  step1 := regex.replace(expr, `/[ \t]*\r?\n[ \t\r\n]*`, "/")
  rejoined := regex.replace(step1, `[ \t\r\n]*\r?\n[ \t]*/`, "/")

  normalized := replace(replace(replace(replace(replace(replace(replace(replace(replace(rejoined, "[", " "), "]", " "), "AND", " "), "OR", " "), ")", " "), "(", " ") ,"\t"," "),"\r"," "),"\n"," ")
  parts := split(normalized, " ")

  vars := {trim_prefix(trim(p, " "), "$") |
    p := parts[_]
    startswith(p, "$")
  }
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Depends on: type_of.rego.part
# ---------------------------------------------------------
is_change_variable_action(a) if {
  contains(lower(type_of(a)), "changevariableaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Depends on: type_of.rego.part
# ---------------------------------------------------------
is_create_variable_action(a) if {
  contains(lower(type_of(a)), "createvariableaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Flattens a microflow's nested ObjectCollection.Objects tree
# (up to 4 levels of nesting, e.g. inside loops/exclusive splits)
# into one set, and extracts the Action of every ActionActivity.
# ---------------------------------------------------------
actions := [a |
  aa := all_microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"

  a := object.get(aa, "Action", null)
  a != null
]

all_microflow_objects := objs if {
  objs := {o |
    o := microflow_objects_lvl0[_]
  } |
  {o |
    o := microflow_objects_lvl1[_]
  } |
  {o |
    o := microflow_objects_lvl2[_]
  } |
  {o |
    o := microflow_objects_lvl3[_]
  } |
  {o |
    o := microflow_objects_lvl4[_]
  }
}

microflow_objects_lvl0 := input.ObjectCollection.Objects

microflow_objects_lvl1 := [o |
  parent := microflow_objects_lvl0[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl2 := [o |
  parent := microflow_objects_lvl1[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl3 := [o |
  parent := microflow_objects_lvl2[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl4 := [o |
  parent := microflow_objects_lvl3[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Identifies "retrieve or create" pattern microflows by name,
# and whether they delegate to another microflow (in which case
# the retrieve/create checks that live in the caller don't apply).
# Depends on: microflow_object_tree.rego.part (actions)
# ---------------------------------------------------------
is_retrieve_or_create_microflow if {
  name := lower(input.Name)
  contains(name, "retrieve")
  contains(name, "create")
}

contains_microflowcall if{
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "microflowcallaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Variables read via a database Retrieve action, either through
# an association path or an XPath constraint.
# Depends on: microflow_object_tree.rego.part (actions),
#             extract_variables.rego.part
# ---------------------------------------------------------

# Assoc retrieve
retrieve_assoc_vars := {v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource","")
  contains(lower(object.get(src, "$Type", "")), "associationretrievesource")

  v := object.get(src, "StartVariableName", "")
  v != ""
}

# XPATH VARIABLE Retrieve
retrieve_xpath_vars := {v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource", null)
  src != null
  contains(lower(object.get(src, "$Type", "")), "databaseretrievesource")

  xpath := object.get(src, "XpathConstraint", "")
  xpath != ""

  v := extract_variables(xpath)[_]
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Deep traversal: collect every string value nested anywhere
# inside an object (used to scan expressions/log messages for
# a substring regardless of which field it's stored in).
#
# Note: standardized to a set here. The original 008_0004 had this
# as an array comprehension, but every call site only ever iterates
# it with `strings_in_object(x)[_]`, which is order-independent, so
# using a set here is behavior-preserving for both callers.
# ---------------------------------------------------------
strings_in_object(x) := {s |
  some path, v
  walk(x, [path, v])
  is_string(v)
  s := v
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Type accessor: Mendix modelsource YAML uses either $Type or
# $type depending on export version.
# ---------------------------------------------------------
type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if { true }
