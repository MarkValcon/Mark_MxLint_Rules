# METADATA
# scope: package
# title: Sensitive constant has a hardcoded default value or is exposed to client
# description: A constant whose name suggests it holds a secret (key, encrypt, hash, salt, password, secret, token) should never carry a hardcoded literal as its DefaultValue, and should never be exposed to client code - both make the secret retrievable outside the environment configuration that is meant to hold it.
# authors:
# - Mark van der Smagt
# custom:
#  category: Security
#  rulename: HardcodedOrExposedSensitiveConstant
#  severity: HIGH
#  rulenumber: 008_0011
#  remediation: Clear the constant's DefaultValue (leave it empty) and set the real value only through a private, per-environment configuration value. If the constant does not need to be readable by client code, disable ExposedToClient.
#  input: .*Constants\$Constant\.yaml
package app.mendix.security.hardcoded_or_exposed_sensitive_constant

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

trigger_keywords := {"key", "encrypt", "hash", "salt", "password", "secret", "token"}

is_sensitive_name(name) if {
  kw := trigger_keywords[_]
  contains(lower(name), kw)
}

# ---------------------------------------------------------
# RULE 1: sensitive constant has a hardcoded non-empty DefaultValue
# ---------------------------------------------------------
errors contains err if {
  is_sensitive_name(input.Name)

  dv := object.get(input, "DefaultValue", "")
  dv != ""

  err := sprintf("[%v, %v, %v] Constant %v has a hardcoded default value - clear DefaultValue and configure the real value privately per environment.",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      input.Name,
    ]
  )
}

# ---------------------------------------------------------
# RULE 2: sensitive constant is exposed to client code
# ---------------------------------------------------------
errors contains err if {
  is_sensitive_name(input.Name)

  object.get(input, "ExposedToClient", false) == true

  err := sprintf("[%v, %v, %v] Constant %v is exposed to client code - a constant with a sensitive name should not be readable from the client.",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      input.Name,
    ]
  )
}
