# METADATA
# scope: package
# title: Error-prone activities must use custom error handling
# description: Error-handling of error-prone activities should be done explicitly
# authors:
# - Mark van der Smagt
# custom:
#  category: Reliability
#  rulename: ErrorProneActivitiesMustUseCustomErrorHandling
#  severity: MEDIUM
#  rulenumber: 008_0003
#  remediation: Set ErrorHandlingType to Custom, and properly handle the error yourself
#  input: .*\.Microflows\$Microflow\.yaml
package app.mendix.microflows.error_prone_custom_error_handling

import rego.v1

# GENERATED FILE - do not edit the .rego output directly.
# Source: src/rules/008_0003_error_prone_custom_error_handling.rule.part
# plus shared parts listed in generate.sh, assembled by generate.sh.
#
# Note: originally defined its own `allowed_error_handling` constant with the same
# value as 008_0004's `allowed_custom_error_handling`. Both now use the shared
# allowed_custom_error_handling.rego.part; error_handling_ok below was updated to
# reference that shared name instead of allowed_error_handling.

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

# ---------------------------------------------------------
# Maintainable config
# ---------------------------------------------------------

error_prone_action_types := [
  {"match": "microflows$javaactioncallaction", "label": "Java action"},
  {"match": "microflows$importxmlaction",      "label": "Import mapping (ImportXmlAction)"},
  {"match": "microflows$restcallaction",      "label": "Call REST"},
  {"match": "microflows$restoperationcallaction",      "label": "Send REST request"},
  {"match": "microflows$callwebserviceaction",      "label": "Call Web Service"},
  {"match": "microflows$callexternalaction",      "label": "Call external action"},
  {"match":  "exceldataimporter$importexceldataaction", "label": "Data Importer Mapping"},
  {"match":  "microflows$Downloadfileaction", "label": "Download file"}

]

error_prone_expression_functions := {
  "substring",
  "parseDateTime",
  "parseDateTimeUTC",
  "parseDecimal"
}

whitelisted_java_actions := {
  "objecthandling.starttransaction", #Error handling will not work on this java action, additonally these are already flagged by rule 008_005_DontMessWithTransactions
  "objecthandling.endtransaction",
  "communitycommons.starttransaction",
  "communitycommons.endtransaction",
  "communitycommons.commitinseparatedatabasetransaction",
  "communitycommons.getguid", #Sometimes used in loops and almost never fails
  "communitycommons.randomhash", #Not dependent on context, never fails
  "communitycommons.throwexception", #Adding error handling here would defeat the purpose
  "communitycommons.throwwebserviceexception", #Adding error handling here would defeat the purpose
  "communitycommons.getruntimeversion", #Not dependent on context, never fails
  "communitycommons.getmodelversion", #Not dependent on context, never fails
  "communitycommons.getapplicationurl", #Not dependent on context, never fails
  "communitycommons.isindevelopment", #Not dependent on context, never fails
  "mxmodelreflection.syncobjects", #Admin action, not dependent on context
  "communitycommons.delay", #Not dependent on context
  "communitycommons.timemeasurestart", #Not dependent on context
  "communitycommons.timemeasureend"  #Not dependent on context
}

# ---------------------------------------------------------
# Errors
# ---------------------------------------------------------


errors contains err if {
  ep := error_prone_expressions[_]
  a := ep.action

  not error_handling_ok(a)

  err := sprintf("[%v, %v, %v] %v contains error-prone expressions %v and must use custom error handling",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      ep.caption,
      ep.functions

    ]
  )
}


errors contains err if {
  ep := error_prone_activities[_]
  a := ep.action

  not error_handling_ok(a)
  display := action_display_name(a, ep.kind)

  err := sprintf("[%v, %v, %v] %v must use custom error handling",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      display
    ]
  )
}


# ---------------------------------------------------------
# Determine which activities are error-prone
# ---------------------------------------------------------

error_prone_activities := [info |
  a := actions[_]

  # error_prone_label already excludes whitelisted/parameterless Java
  # actions internally (it fails to produce a result for them), so
  # re-checking is_whitelisted_java_action/has_no_java_parameters here
  # would just re-evaluate the same two predicates a second time for
  # every matching action.
  label := error_prone_label(a)

  info := {
    "action": a,
    "caption": activity_caption(a),
    "kind": label
  }
]

# ---------------------------------------------------------
# Determine which expressions are error-prone
# ---------------------------------------------------------

error_prone_expressions := [info |
  a := actions[_]


  funcs := error_prone_functions_in_action(a)
  count(funcs) > 0

  info := {
    "action": a,
    "caption": activity_caption(a),
    "functions": funcs
  }
]


error_prone_label(a) := label if {
  t := lower(type_of(a))
  d := error_prone_action_types[_]
  contains(t, d.match)
  label := d.label

  # skip whitelisted Java actions
  not is_whitelisted_java_action(a)
  # skip Java actions with no input parameters (context-independent, CR-013)
  not has_no_java_parameters(a)

}



error_prone_functions_in_action(a) := funcs if {
  funcs := {fn |
    some s in strings_in_object(a)
    e := lower(s)
    fn := error_prone_expression_functions[_]
    contains(e, sprintf("%v(", [fn]))
  }
} else := {} if { true }



# ---------------------------------------------------------
# Error handling checks
# ---------------------------------------------------------

error_handling_ok(a) if {
  eht_raw := object.get(a, "ErrorHandlingType", "")
  eht_raw != ""
  eht := normalize_eht(eht_raw)
  eht in allowed_custom_error_handling
}

# ---------------------------------------------------------
# Whitelisted java actions
# ---------------------------------------------------------

is_whitelisted_java_action(a) if {
  contains(lower(type_of(a)), "javaactioncallaction")

  action_name := lower(object.get(a, "JavaAction", ""))
  action_name != ""

  action_name == whitelisted_java_actions[_]
}

# ---------------------------------------------------------
# Java actions with no input parameters (CR-013)
#
# A Java action call that takes no parameters only ever depends on its own
# code, never on anything passed in from the calling microflow - i.e. it is
# context-independent, the same reasoning behind whitelisted_java_actions
# entries like GetGuid/RandomHash/GetRuntimeVersion. This generalizes that
# reasoning instead of requiring every such action to be added by name.
# ---------------------------------------------------------

has_no_java_parameters(a) if {
  contains(lower(type_of(a)), "javaactioncallaction")

  params := object.get(a, "ParameterMappings", [])
  count(params) == 0
}



action_display_name(a, kind) := name if {
  is_java_action(a)

  raw := java_action_name(a)
  name := raw
} else := kind if {
  not is_java_action(a)
}



java_action_name(a) := name if {
  name := object.get(a, "JavaAction", "")
  name != ""
} else := "Unknown JavaAction" if { true }




is_java_action(a) if {
  contains(lower(type_of(a)), "javaactioncallaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Preferred display name for an activity in lint messages.
# Caption is the modeler-facing label, but it's frequently left blank -
# fall back to the variable the activity assigns its result to
# (ResultVariableName, or VariableName for the activity kinds that use
# that field instead), and only fall back further to the raw activity
# type if neither is set.
#
# Depends on: type_of.rego.part
# ---------------------------------------------------------
activity_caption(aa) := c if {
  c0 := object.get(aa, "Caption", "")
  c0 != ""
  c := c0
} else := c if {
  c0 := object.get(aa, "ResultVariableName", "")
  c0 != ""
  c := c0
} else := c if {
  c0 := object.get(aa, "VariableName", "")
  c0 != ""
  c := c0
} else := type_of(aa) if { true }

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# The set of ErrorHandlingType values (after normalize_eht) that
# count as "custom" error handling.
# Note: 008_0003 originally called this constant allowed_error_handling
# and 008_0004 called it allowed_custom_error_handling - same value,
# different name. Standardized on allowed_custom_error_handling.
# ---------------------------------------------------------
allowed_custom_error_handling := {
  "customwithrollback",
  "customwithoutrollback",
  "custom"
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Variables derived from $latestError via a Create or Change variable
# action whose InitialValue/Value contains "$latestError" (e.g.
# $ErrorMsg := $latestError/Message). Lets a rule recognize error-handling
# code that references the error indirectly through such a variable, not
# just $latestError itself.
#
# Was previously hand-duplicated (byte-for-byte) inside both
# 008_0004_custom_error_handling_latest_error_usage.rule.part and
# 008_0015_no_raw_error_messages_to_user.rule.part - consolidated here.
#
# Depends on: microflow_object_tree.rego.part (actions),
#             is_create_variable_action.rego.part,
#             is_change_variable_action.rego.part
# ---------------------------------------------------------
derived_error_vars := derived_create_vars | derived_change_vars

derived_create_vars := {v |
  act := actions[_]
  is_create_variable_action(act)

  expr := object.get(act, "InitialValue", "")
  contains(expr, "$latestError")

  v := object.get(act, "VariableName", "")
  v != ""
}

derived_change_vars := {v |
  act := actions[_]
  is_change_variable_action(act)

  expr := object.get(act, "Value", "")
  contains(expr, "$latestError")

  v := object.get(act, "ChangeVariableName", "")
  v != ""
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Normalizes an ErrorHandlingType value (e.g. "Custom With Rollback",
# "custom_with_rollback") down to a comparable lowercase-letters-only
# form, e.g. "customwithrollback".
# ---------------------------------------------------------
normalize_eht(s) := out if {
  lower_s := lower(s)
  no_sep := replace(replace(replace(lower_s, " ", ""), "_", ""), "-", "")
  chars := [c | c := split(no_sep, "")[_]; is_letter(c)]
  out := concat("", chars)
}

is_letter(c) if {
  c >= "a"
  c <= "z"
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Pulls every $Variable reference out of an XPath constraint or any other
# microflow expression string (list-operation filters, decision-split
# conditions, ...).
# ---------------------------------------------------------
extract_variables(expr) := vars if {
  # Mendix can export (or a modeler can author) an expression with a
  # literal line break landing inside a compound $Var/Association path,
  # e.g. "$HouseHold/\nAddress" instead of "$HouseHold/Address". Rejoin
  # a newline that touches a "/" before treating whitespace as a token
  # separator below, or the segment after the break (here "Address")
  # gets silently dropped since it no longer starts with "$". Only a
  # newline-containing whitespace run adjacent to "/" is collapsed here
  # - plain spaces around "/" (e.g. "$Amount / 2") are left untouched,
  # so this can't merge two space-separated $Var tokens either side of
  # a division operator.
  step1 := regex.replace(expr, `/[ \t]*\r?\n[ \t\r\n]*`, "/")
  rejoined := regex.replace(step1, `[ \t\r\n]*\r?\n[ \t]*/`, "/")

  normalized := replace(replace(replace(replace(replace(replace(replace(replace(replace(rejoined, "[", " "), "]", " "), "AND", " "), "OR", " "), ")", " "), "(", " ") ,"\t"," "),"\r"," "),"\n"," ")
  parts := split(normalized, " ")

  vars := {trim_prefix(trim(p, " "), "$") |
    p := parts[_]
    startswith(p, "$")
  }
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Depends on: type_of.rego.part
# ---------------------------------------------------------
is_change_variable_action(a) if {
  contains(lower(type_of(a)), "changevariableaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Depends on: type_of.rego.part
# ---------------------------------------------------------
is_create_variable_action(a) if {
  contains(lower(type_of(a)), "createvariableaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Flattens a microflow's nested ObjectCollection.Objects tree
# (up to 4 levels of nesting, e.g. inside loops/exclusive splits)
# into one set, and extracts the Action of every ActionActivity.
# ---------------------------------------------------------
actions := [a |
  aa := all_microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"

  a := object.get(aa, "Action", null)
  a != null
]

all_microflow_objects := objs if {
  objs := {o |
    o := microflow_objects_lvl0[_]
  } |
  {o |
    o := microflow_objects_lvl1[_]
  } |
  {o |
    o := microflow_objects_lvl2[_]
  } |
  {o |
    o := microflow_objects_lvl3[_]
  } |
  {o |
    o := microflow_objects_lvl4[_]
  }
}

microflow_objects_lvl0 := input.ObjectCollection.Objects

microflow_objects_lvl1 := [o |
  parent := microflow_objects_lvl0[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl2 := [o |
  parent := microflow_objects_lvl1[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl3 := [o |
  parent := microflow_objects_lvl2[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl4 := [o |
  parent := microflow_objects_lvl3[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Identifies "retrieve or create" pattern microflows by name,
# and whether they delegate to another microflow (in which case
# the retrieve/create checks that live in the caller don't apply).
# Depends on: microflow_object_tree.rego.part (actions)
# ---------------------------------------------------------
is_retrieve_or_create_microflow if {
  name := lower(input.Name)
  contains(name, "retrieve")
  contains(name, "create")
}

contains_microflowcall if{
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "microflowcallaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Variables read via a database Retrieve action, either through
# an association path or an XPath constraint.
# Depends on: microflow_object_tree.rego.part (actions),
#             extract_variables.rego.part
# ---------------------------------------------------------

# Assoc retrieve
retrieve_assoc_vars := {v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource","")
  contains(lower(object.get(src, "$Type", "")), "associationretrievesource")

  v := object.get(src, "StartVariableName", "")
  v != ""
}

# XPATH VARIABLE Retrieve
retrieve_xpath_vars := {v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource", null)
  src != null
  contains(lower(object.get(src, "$Type", "")), "databaseretrievesource")

  xpath := object.get(src, "XpathConstraint", "")
  xpath != ""

  v := extract_variables(xpath)[_]
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Deep traversal: collect every string value nested anywhere
# inside an object (used to scan expressions/log messages for
# a substring regardless of which field it's stored in).
#
# Note: standardized to a set here. The original 008_0004 had this
# as an array comprehension, but every call site only ever iterates
# it with `strings_in_object(x)[_]`, which is order-independent, so
# using a set here is behavior-preserving for both callers.
# ---------------------------------------------------------
strings_in_object(x) := {s |
  some path, v
  walk(x, [path, v])
  is_string(v)
  s := v
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Type accessor: Mendix modelsource YAML uses either $Type or
# $type depending on export version.
# ---------------------------------------------------------
type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if { true }
