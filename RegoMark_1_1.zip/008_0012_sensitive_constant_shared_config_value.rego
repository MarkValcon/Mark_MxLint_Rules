# METADATA
# scope: package
# title: Sensitive constant configured with a shared value
# description: A constant whose name suggests it holds a secret (key, encrypt, hash, salt, password, secret, token) must not be configured with a Settings$SharedValue in a server configuration - a shared value is stored in the model/config and applies to every environment, which defeats keeping the secret out of the model. Only a Settings$PrivateValue (set per environment, never stored in the model source) is acceptable.
# authors:
# - Mark van der Smagt
# custom:
#  category: Security
#  rulename: SensitiveConstantSharedConfigValue
#  severity: HIGH
#  rulenumber: 008_0012
#  remediation: Change the constant's configured value from a shared value to a private value, and set the real value per environment (e.g. via the Mendix Cloud portal or an environment variable), not in the model's configuration.
#  input: .*Settings\$ProjectSettings\.yaml
package app.mendix.security.sensitive_constant_shared_config_value

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

trigger_keywords := {"key", "encrypt", "hash", "salt", "password", "secret", "token"}

is_sensitive_constant_id(id) if {
  kw := trigger_keywords[_]
  contains(lower(id), kw)
}

part_type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if { true }

configuration_settings_parts := [p |
  p := object.get(input, "Settings", [])[_]
  part_type_of(p) == "Settings$ConfigurationSettings"
]

all_constant_values := [cv |
  part := configuration_settings_parts[_]
  cfg := object.get(part, "Configurations", [])[_]
  cv := object.get(cfg, "ConstantValues", [])[_]
]

errors contains err if {
  cv := all_constant_values[_]

  id := object.get(cv, "ConstantId", "")
  is_sensitive_constant_id(id)

  shared_or_private := object.get(cv, "SharedOrPrivateValue", {})
  part_type_of(shared_or_private) == "Settings$SharedValue"

  err := sprintf("[%v, %v, %v] Constant %v is configured with a shared value in this server configuration - use a private, per-environment value instead.",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      id,
    ]
  )
}
